﻿namespace XProtocol
{
    public enum XPacketType
    {
        Unknown,
        Handshake,
        EventMessage
    }
}
